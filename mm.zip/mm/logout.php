<?php
    session_start();
    unset($_SESSTION['admin_login']);
    unset($_SESSTION['user_login']);

    header('location: login.php');
?>